import { useCallback, useState } from "react";
import { Alert, AppState, ScrollView, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { refreshProfile, ensureDevSession } from "@/services/authService";
import { startTelemetry, stopTelemetry } from "@/services/telemetryService";
import {
  getLocationPermState,
  openAppLocationSettings,
  requestTechnicianLocationPermissions,
} from "@/services/locationPermissions";
import { getPushStatus, type PushStatus } from "@/services/jobDispatchWatcher";
import { registerForPushNotifications } from "@/services/pushNotificationService";
import { useAuthStore } from "@/store/authStore";
import { useSyncStore } from "@/store/syncStore";
import { colors } from "@/constants/theme";
import { SKIP_LOGIN } from "@/constants/dev";
import { ERP_BASE_URL } from "@/services/api";

export default function ProfileScreen() {
  const router = useRouter();
  const { employee, logout, isTechnician } = useAuthStore();
  const pendingCount = useSyncStore((s) => s.pendingCount);
  const tech = isTechnician();
  const [trackingOn, setTrackingOn] = useState<boolean | null>(null);
  const [pushStatus, setPush] = useState<PushStatus | null>(null);

  const profile = useQuery({
    queryKey: ["profile", employee?.id],
    enabled: !!employee?.id,
    queryFn: () => refreshProfile(employee!.id),
  });

  const emp = profile.data?.employee ?? employee;

  useFocusEffect(
    useCallback(() => {
      if (!tech) return;
      void getLocationPermState().then((p) => setTrackingOn(p.trackingReady));
      void getPushStatus().then(setPush);
      const sub = AppState.addEventListener("change", (s) => {
        if (s === "active") {
          void getLocationPermState().then((p) => setTrackingOn(p.trackingReady));
          void getPushStatus().then(setPush);
        }
      });
      return () => sub.remove();
    }, [tech])
  );

  async function onLogout() {
    stopTelemetry();
    await logout();
    if (SKIP_LOGIN) {
      await ensureDevSession();
      router.replace("/(tabs)");
      return;
    }
    router.replace("/(auth)/login");
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
    >
      <Text style={{ color: colors.text, fontSize: 22, fontWeight: "800" }}>Profile</Text>

      <Card style={{ marginTop: 14 }}>
        <Text style={{ color: colors.text, fontSize: 18, fontWeight: "800" }}>{emp?.name}</Text>
        <Text style={{ color: colors.primary, marginTop: 4, fontWeight: "600" }}>{emp?.role}</Text>
        <Text style={{ color: colors.textMuted, marginTop: 8 }}>
          {emp?.designation ?? "—"} · {emp?.department ?? "—"}
        </Text>
        <Text style={{ color: colors.textDim, marginTop: 6, fontSize: 12 }}>
          {emp?.phone ?? emp?.email ?? emp?.id}
        </Text>
      </Card>

      {tech && (
        <Card style={{ marginTop: 12 }}>
          <Text style={{ color: colors.text, fontWeight: "700" }}>Live location</Text>
          <Text
            style={{
              color: trackingOn ? colors.success : colors.warning,
              marginTop: 8,
              fontWeight: "600",
            }}
          >
            {trackingOn == null
              ? "Checking…"
              : trackingOn
                ? "On — dispatch can see you"
                : "Off — enable background location"}
          </Text>
          {!trackingOn && trackingOn !== null ? (
            <View style={{ marginTop: 12 }}>
              <Button
                title="Enable tracking"
                onPress={() => {
                  void (async () => {
                    const perms = await requestTechnicianLocationPermissions();
                    setTrackingOn(perms.trackingReady);
                    if (perms.trackingReady && employee?.id) {
                      await startTelemetry(employee.id);
                    } else {
                      openAppLocationSettings();
                    }
                  })();
                }}
              />
            </View>
          ) : null}
        </Card>
      )}

      {tech ? (
        <Card style={{ marginTop: 12 }}>
          <Text style={{ color: colors.text, fontWeight: "700" }}>Job alerts</Text>
          <Text
            style={{
              color: pushStatus?.ok ? colors.success : colors.warning,
              marginTop: 8,
              fontWeight: "600",
              lineHeight: 20,
            }}
          >
            {pushStatus?.detail ??
              "Checking… Keep the app open or live location on so new jobs can ring."}
          </Text>
          <View style={{ marginTop: 12 }}>
            <Button
              title="Retry cloud push"
              variant="secondary"
              onPress={() => {
                void (async () => {
                  if (!employee?.id) return;
                  await registerForPushNotifications(employee.id);
                  setPush(await getPushStatus());
                })();
              }}
            />
          </View>
        </Card>
      ) : null}

      <Card style={{ marginTop: 12 }}>
        <Text style={{ color: colors.textDim, fontSize: 12 }}>Server</Text>
        <Text style={{ color: colors.textMuted, marginTop: 4 }} numberOfLines={1}>
          {ERP_BASE_URL}
        </Text>
        <Text style={{ color: colors.textDim, marginTop: 6, fontSize: 12 }}>
          {pendingCount} offline pending
        </Text>
      </Card>

      <View style={{ marginTop: 16, gap: 10 }}>
        <Button
          title="Face enrollment"
          variant="secondary"
          onPress={() => router.push("/enrollment")}
        />
        <Button
          title="Sign Out"
          variant="danger"
          onPress={() =>
            Alert.alert("Sign out?", "You’ll need your password again.", [
              { text: "Cancel", style: "cancel" },
              { text: "Sign Out", style: "destructive", onPress: onLogout },
            ])
          }
        />
      </View>
    </ScrollView>
  );
}
