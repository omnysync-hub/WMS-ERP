import { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { transitionJob } from "@/services/jobsService";
import { useAuthStore } from "@/store/authStore";
import { colors } from "@/constants/theme";
import { toast } from "@/store/toastStore";
import { haptic } from "@/lib/haptics";
import type { JobItem } from "@/types";

export default function DiscountModal() {
  const { jobId, itemsJson } = useLocalSearchParams<{
    jobId: string;
    itemsJson?: string;
  }>();
  const router = useRouter();
  const qc = useQueryClient();
  const actor = useAuthStore((s) => s.employee?.name) ?? "Technician";

  const items = useMemo(() => {
    try {
      return JSON.parse(itemsJson || "[]") as JobItem[];
    } catch {
      return [] as JobItem[];
    }
  }, [itemsJson]);

  const [itemId, setItemId] = useState(items[0]?.id ?? "");
  const [discount, setDiscount] = useState("");
  const [reason, setReason] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      transitionJob(jobId!, {
        action: "request_item_discount",
        itemId,
        discountRequested: Number(discount) || 0,
        reason,
        actor,
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job", jobId] });
      toast("Discount request sent", "success");
      router.back();
    },
    onError: (e: Error) => {
      toast(e.message, "error");
      Alert.alert("Couldn't send", e.message);
    },
  });

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
    >
      <Text style={{ color: colors.text, fontSize: 20, fontWeight: "800" }}>Ask for discount</Text>
      <Text style={{ color: colors.textMuted, marginTop: 6, marginBottom: 16, lineHeight: 20 }}>
        Pick the line item and how much off. Accounts will approve.
      </Text>

      {items.length > 0 ? (
        <View style={{ gap: 8, marginBottom: 14 }}>
          {items.map((it) => {
            const active = itemId === it.id;
            return (
              <Pressable
                key={it.id}
                onPress={() => {
                  void haptic.select();
                  setItemId(it.id);
                }}
                style={{
                  padding: 14,
                  borderRadius: 12,
                  backgroundColor: active ? colors.primary : colors.surface,
                  borderWidth: 1,
                  borderColor: active ? colors.primary : colors.border,
                }}
              >
                <Text style={{ color: colors.text, fontWeight: "700" }}>
                  {it.name ?? it.description ?? "Item"}
                </Text>
              </Pressable>
            );
          })}
        </View>
      ) : (
        <>
          <Text style={{ color: colors.textDim, marginBottom: 6 }}>Item ID</Text>
          <TextInput
            value={itemId}
            onChangeText={setItemId}
            placeholder="Item id"
            placeholderTextColor={colors.textDim}
            style={field}
          />
        </>
      )}

      <Text style={{ color: colors.textDim, marginBottom: 6 }}>Discount (PKR)</Text>
      <TextInput
        value={discount}
        onChangeText={setDiscount}
        keyboardType="decimal-pad"
        placeholder="500"
        placeholderTextColor={colors.textDim}
        style={field}
      />

      <Text style={{ color: colors.textDim, marginTop: 12, marginBottom: 6 }}>Why?</Text>
      <TextInput
        value={reason}
        onChangeText={setReason}
        multiline
        placeholder="Customer asked for a small concession"
        placeholderTextColor={colors.textDim}
        style={[field, { minHeight: 90, textAlignVertical: "top" }]}
      />

      <Button
        title="Send request"
        loading={mutation.isPending}
        style={{ marginTop: 18 }}
        onPress={() => {
          if (!itemId || !discount) {
            Alert.alert("Pick an item and amount");
            return;
          }
          mutation.mutate();
        }}
      />
    </ScrollView>
  );
}

const field = {
  backgroundColor: colors.surface,
  borderColor: colors.border,
  borderWidth: 1,
  borderRadius: 12,
  color: colors.text,
  padding: 12,
  minHeight: 48,
} as const;
