import { useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { ScreenHeader } from "@/components/ui/ScreenHeader";
import { api } from "@/services/api";
import { useAuthStore } from "@/store/authStore";
import { colors, radius, space, tapMin, type } from "@/constants/theme";
import { toast } from "@/store/toastStore";
import { haptic } from "@/lib/haptics";

type Draft = {
  key: string;
  amount: string;
  note: string;
};

function blankDraft(): Draft {
  return { key: `e-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, amount: "", note: "" };
}

export default function NewExpenseScreen() {
  const { jobId } = useLocalSearchParams<{ jobId: string }>();
  const router = useRouter();
  const technicianId = useAuthStore((s) => s.employee?.id);
  const [rows, setRows] = useState<Draft[]>([blankDraft()]);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!technicianId) throw new Error("Not signed in");
      if (!jobId) throw new Error("Missing job");

      const valid = rows
        .map((r) => ({
          amount: Number(r.amount) || 0,
          note: r.note.trim() || "Field expense",
        }))
        .filter((r) => r.amount > 0);

      if (valid.length === 0) throw new Error("Enter at least one amount");

      const results = [];
      for (const row of valid) {
        const res = await api.claimJobExpense(jobId, {
          technicianId,
          amount: row.amount,
          note: row.note,
        });
        results.push(res);
      }
      return results;
    },
    onSuccess: (results) => {
      toast(
        results.length === 1
          ? "Expense saved"
          : `${results.length} expenses saved`,
        "success"
      );
      router.back();
    },
    onError: (e: Error) => {
      toast(e.message, "error");
      Alert.alert("Couldn't save", e.message);
    },
  });

  function updateRow(key: string, patch: Partial<Draft>) {
    setRows((prev) => prev.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  function addRow() {
    void haptic.press();
    setRows((prev) => [...prev, blankDraft()]);
  }

  function removeRow(key: string) {
    void haptic.select();
    setRows((prev) => (prev.length <= 1 ? [blankDraft()] : prev.filter((r) => r.key !== key)));
  }

  const filledCount = rows.filter((r) => Number(r.amount) > 0).length;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: space.lg, paddingBottom: 40 }}
      keyboardShouldPersistTaps="handled"
    >
      <ScreenHeader
        title="Log expenses"
        subtitle="Add one or many — each gets its own amount and note."
      />

      {rows.map((row, index) => (
        <View
          key={row.key}
          style={{
            backgroundColor: colors.surface,
            borderWidth: 1,
            borderColor: colors.border,
            borderRadius: radius.lg,
            padding: space.lg,
            marginBottom: space.md,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: space.md,
            }}
          >
            <Text style={{ color: colors.text, fontWeight: "800" }}>
              Expense {index + 1}
            </Text>
            {rows.length > 1 ? (
              <Pressable
                onPress={() => removeRow(row.key)}
                style={{ minHeight: tapMin, justifyContent: "center", paddingHorizontal: 4 }}
              >
                <Text style={{ color: colors.danger, fontWeight: "700" }}>Remove</Text>
              </Pressable>
            ) : null}
          </View>

          <Text style={{ color: colors.textDim, marginBottom: space.xs, ...type.label }}>
            Amount (PKR)
          </Text>
          <TextInput
            value={row.amount}
            onChangeText={(t) => updateRow(row.key, { amount: t })}
            keyboardType="decimal-pad"
            placeholder="1200"
            placeholderTextColor={colors.textDim}
            style={field}
          />

          <Text
            style={{
              color: colors.textDim,
              marginTop: space.md,
              marginBottom: space.xs,
              ...type.label,
            }}
          >
            What for?
          </Text>
          <TextInput
            value={row.note}
            onChangeText={(t) => updateRow(row.key, { note: t })}
            placeholder="Hardware store · brass fitting"
            placeholderTextColor={colors.textDim}
            style={field}
          />
        </View>
      ))}

      <Button title="Add another expense" variant="secondary" onPress={addRow} />

      <Button
        title={
          filledCount <= 1
            ? "Save expense"
            : `Save ${filledCount} expenses`
        }
        loading={mutation.isPending}
        style={{ marginTop: space.md }}
        onPress={() => mutation.mutate()}
      />
    </ScrollView>
  );
}

const field = {
  backgroundColor: colors.surfaceElevated,
  borderColor: colors.border,
  borderWidth: 1,
  borderRadius: radius.md,
  color: colors.text,
  padding: space.md,
  minHeight: 48,
  fontSize: 16,
} as const;
