"use client";

import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  CreditCard,
  Scale,
  Receipt,
  PackageCheck,
  ShoppingCart,
  Eye,
  ArrowRight,
  Sparkles,
  Printer,
} from "lucide-react";
import { formatCurrency, formatDateTime, cn } from "@/lib/utils";
import {
  ProcurementStatusBadge,
  ProcurementEmptyState,
} from "@/components/procurement/procurementUi";
import SideDrawer from "@/components/ui/SideDrawer";
import SearchableSelect from "@/components/ui/SearchableSelect";
import VendorBillDocument from "@/components/documents/VendorBillDocument";
import { printDocument } from "@/lib/printUtils";

import { useRole } from "@/contexts/RoleContext";
import { procurementActorHeaders } from "@/lib/procurementClient";

interface ThreeWayMatchTabProps {
  invoices: any[];
  pos: any[];
  grns: any[];
  vendors: any[];
  onRefresh: () => void;
  onNavigateToPayment?: (invoice: any) => void;
  queueFilter?: string | null;
}

function matchStatusLabel(status: string) {
  const s = (status || "").toLowerCase();
  if (s === "matched") return { label: "Matched ✓", hint: "PO · GRN · Invoice quantities & prices align" };
  if (s === "discrepancy") return { label: "Discrepancy", hint: "Variance detected — review before approval" };
  if (s === "approved_for_payment") return { label: "Approved for payment", hint: "Cleared 3-way match" };
  if (s === "paid") return { label: "Paid", hint: "Settled" };
  return { label: "Pending match", hint: "Awaiting PO/GRN reconciliation" };
}

export default function ThreeWayMatchTab({
  invoices,
  pos,
  grns,
  vendors,
  onRefresh,
  onNavigateToPayment,
  queueFilter = null,
}: ThreeWayMatchTabProps) {
  const { currentRole, activeRole, hasPermission, currentPersona, activeUser } = useRole();
  const canCreateInvoice = hasPermission("procurement.invoice.create");
  const canApproveInvoice = hasPermission("procurement.invoice.approve");
  const isStorekeeper = currentRole === "storekeeper";

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState(queueFilter || "all");

  // queueFilter sync
  useEffect(() => {
    if (queueFilter) setStatusFilter(queueFilter);
  }, [queueFilter]);

  if (isStorekeeper) {
    return (
      <div className="p-8 text-center bg-white border border-[#EDEDED] rounded-xl space-y-3 shadow-2xs">
        <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-bold text-[#18181B]">Vendor Invoicing & Rates Protected</h3>
        <p className="text-xs text-[#71717A] max-w-md mx-auto">
          In accordance with storekeeper role security protocols, vendor invoices, purchasing rates, and 3-way match financial reconciliations are restricted to Finance & Accounts personnel.
        </p>
      </div>
    );
  }

  // Create Supplier Invoice Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [vendorId, setVendorId] = useState("");
  const [selectedPoId, setSelectedPoId] = useState("");
  const [selectedGrnIds, setSelectedGrnIds] = useState<string[]>([]);
  const [invoiceDate, setInvoiceDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split("T")[0];
  });
  const [taxAmount, setTaxAmount] = useState("0");
  const [matchNotes, setMatchNotes] = useState("");

  const [billedItems, setBilledItems] = useState<
    {
      poItemId: string;
      grnItemId: string;
      grnNumber?: string;
      productId?: string;
      description: string;
      poUnitPrice: number;
      grnQuantity: number;
      billedQuantity: number;
      billedUnitPrice: number;
    }[]
  >([]);

  // Selected Invoice for Full 3-Way Match Verification Card
  const [activeInvoice, setActiveInvoice] = useState<any | null>(null);
  // Selected Invoice for Formal Printable Bill / 3-Way Match Voucher
  const [printableBill, setPrintableBill] = useState<any | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  const rebuildBilledItems = (poId: string, grnIds: string[]) => {
    const po = pos.find((p) => p.id === poId);
    if (!po) {
      setBilledItems([]);
      return;
    }
    const chosenGrns = grns.filter((g) => grnIds.includes(g.id));
    const allAcceptedGrnItems = chosenGrns.flatMap((g) =>
      (g.items || []).map((gi: any) => ({ ...gi, grnNumber: g.grnNumber }))
    );

    if (allAcceptedGrnItems.length > 0) {
      setBilledItems(
        allAcceptedGrnItems.map((gi: any) => {
          const poItem = po.items.find((pi: any) => pi.id === gi.poItemId || pi.productId === gi.productId);
          const acceptedQty = gi.quantityAccepted ?? gi.quantityReceived ?? 1;
          const poCost = poItem?.unitCost || 0;

          return {
            poItemId: poItem?.id || "",
            grnItemId: gi.id,
            grnNumber: gi.grnNumber,
            productId: gi.productId || poItem?.productId || undefined,
            description: `${gi.description}${chosenGrns.length > 1 ? ` (${gi.grnNumber})` : ""}`,
            poUnitPrice: poCost,
            grnQuantity: acceptedQty,
            billedQuantity: acceptedQty,
            billedUnitPrice: poCost,
          };
        })
      );
    } else {
      setBilledItems(
        po.items.map((pi: any) => ({
          poItemId: pi.id,
          grnItemId: "",
          grnNumber: "",
          productId: pi.productId || undefined,
          description: pi.description,
          poUnitPrice: pi.unitCost || 0,
          grnQuantity: pi.quantityReceived || pi.quantity,
          billedQuantity: pi.quantityReceived || pi.quantity,
          billedUnitPrice: pi.unitCost || 0,
        }))
      );
    }
  };

  const handlePoSelect = (poId: string) => {
    setSelectedPoId(poId);
    const po = pos.find((p) => p.id === poId);
    if (po) {
      setVendorId(po.vendorId || "");
      const matchingGrns = grns.filter((g) => g.poId === poId);
      const allMatchingIds = matchingGrns.map((g) => g.id);
      setSelectedGrnIds(allMatchingIds);
      setInvoiceNumber(`INV-VND-${Date.now().toString().slice(-5)}`);
      rebuildBilledItems(poId, allMatchingIds);
    } else {
      setSelectedGrnIds([]);
      setBilledItems([]);
    }
  };

  const toggleGrnSelection = (grnId: string) => {
    const updated = selectedGrnIds.includes(grnId)
      ? selectedGrnIds.filter((id) => id !== grnId)
      : [...selectedGrnIds, grnId];
    setSelectedGrnIds(updated);
    rebuildBilledItems(selectedPoId, updated);
  };

  const handleItemChange = (index: number, field: string, val: any) => {
    const updated = [...billedItems];
    (updated[index] as any)[field] = val;
    setBilledItems(updated);
  };

  const calculatedSubtotal = billedItems.reduce(
    (sum, it) => sum + (Number(it.billedQuantity) || 0) * (Number(it.billedUnitPrice) || 0),
    0
  );

  const handleCreateInvoice = async (e: React.FormEvent) => {
    if (!canCreateInvoice) { alert("Missing permission: procurement.invoice.create"); return; }
    e.preventDefault();
    if (!vendorId || !invoiceNumber.trim()) {
      setFormError("Please enter invoice number and select a vendor.");
      return;
    }

    setIsSubmitting(true);
    setFormError("");

    try {
      const res = await fetch("/api/procurement", {
        method: "POST",
        headers: procurementActorHeaders(activeRole || currentRole, currentPersona?.name || activeUser?.name, activeUser?.id),

        body: JSON.stringify({
          action: "create_supplier_invoice",
          invoiceNumber,
          vendorId,
          poId: selectedPoId || undefined,
          grnId: selectedGrnIds[0] || undefined,
          grnIds: selectedGrnIds,
          invoiceDate,
          dueDate,
          taxAmount: Number(taxAmount) || 0,
          matchNotes,
          items: billedItems,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to submit invoice for 3-way match");
      }

      setShowCreateModal(false);
      onRefresh();
    } catch (err: any) {
      setFormError(err.message || "Failed to create supplier invoice");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApproveInvoice = async (invoiceId: string) => {
    if (!canApproveInvoice) { alert("Missing permission: procurement.invoice.approve"); return; }
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/procurement", {
        method: "POST",
        headers: procurementActorHeaders(activeRole || currentRole, currentPersona?.name || activeUser?.name, activeUser?.id),

        body: JSON.stringify({
          action: "approve_supplier_invoice",
          invoiceId,
          actorName: "Fatima Noor (Chief Financial Accountant)",
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to approve invoice");
      }

      alert("3-Way Match Verified! Accounts Payable voucher created and posted to Vendor Ledger.");
      setActiveInvoice(null);
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    const matchStatus = statusFilter === "all" || inv.matchStatus === statusFilter;
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      inv.invoiceNumber?.toLowerCase().includes(q) ||
      inv.referenceNumber?.toLowerCase().includes(q) ||
      inv.vendor?.name?.toLowerCase().includes(q) ||
      inv.po?.poNumber?.toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-4">
      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white border border-[#EDEDED] p-3.5 rounded-xl shadow-2xs">
        <div className="flex items-center gap-2.5 flex-1">
          <div className="relative min-w-[280px] max-w-md">
            <Search className="w-4 h-4 text-[#A1A1AA] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search invoice #, vendor, PO ref..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D4D4D8] rounded-lg text-xs text-[#18181B] placeholder-[#A1A1AA] focus:outline-none focus:ring-1 focus:ring-[#0D7A5F]"
            />
          </div>

          <div className="w-56">
            <SearchableSelect
              value={statusFilter}
              onChange={(val) => setStatusFilter(val)}
              options={[
                { value: "all", label: "All Match Statuses" },
                { value: "matched", label: "Matched (100% Validated)" },
                { value: "discrepancy", label: "Discrepancy (Variance Alert)" },
                { value: "pending_match", label: "Pending Match" },
                { value: "approved_for_payment", label: "Approved for Payment" },
                { value: "paid", label: "Settled / Paid" },
              ]}
              placeholder="Status..."
            />
          </div>
        </div>

        <button
          onClick={() => {
            const firstPo = pos.find((p) => p.goodsReceipts?.length > 0);
            if (firstPo) handlePoSelect(firstPo.id);
            setShowCreateModal(true);
            setFormError("");
          }}
          className="inline-flex items-center gap-1.5 bg-[#0D7A5F] hover:bg-[#0B6851] text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-2xs transition shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          Enter Supplier Invoice (3-Way Match)
        </button>
      </div>

      {/* Invoices Table */}
      <div className="bg-white border border-[#EDEDED] rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="border-b border-[#EDEDED] bg-[#F8FAFC] text-[#71717A] font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">Invoice # & Ref</th>
                <th className="py-3 px-3">Vendor / Supplier</th>
                <th className="py-3 px-3">Linked PO & GRN</th>
                <th className="py-3 px-3">Invoice Date</th>
                <th className="py-3 px-3 text-right">Billed Amount</th>
                <th className="py-3 px-3 text-center">Variance Audit</th>
                <th className="py-3 px-3 text-center">Match Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EDEDED] text-[#18181B]">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-0">
                    <ProcurementEmptyState
                      title="No invoices to match"
                      description="Record a supplier invoice against a GRN to start 3-way match."
                    />
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className="hover:bg-[#F8FAFC] transition-colors group cursor-pointer"
                    onClick={() => setActiveInvoice(inv)}
                  >
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-[#18181B] group-hover:text-[#0D7A5F] transition-colors">
                        {inv.invoiceNumber}
                      </div>
                      <div className="text-[10px] text-[#A1A1AA] font-mono">
                        Ref: {inv.referenceNumber}
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-semibold text-[#18181B]">
                        {inv.vendor?.name}
                      </div>
                      <div className="text-[10px] font-mono text-[#71717A]">
                        Terms: {inv.vendor?.paymentTerms}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px]">
                      <div className="text-[#0D7A5F] font-semibold">
                        PO: {inv.po?.poNumber || "Direct"}
                      </div>
                      <div className="text-[10px] text-[#71717A]">
                        {inv.matchNotes && inv.matchNotes.includes("Consolidated Bill for") ? (
                          <span className="text-purple-700 font-bold bg-purple-50 px-1.5 py-0.2 rounded border border-purple-200">
                            Multi-GRN Consolidated
                          </span>
                        ) : (
                          `GRN: ${inv.grn?.grnNumber || "Direct Receipt"}`
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px] text-[#71717A]">
                      {new Date(inv.invoiceDate || inv.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-[#18181B] text-sm">
                      {formatCurrency(inv.totalAmount)}
                    </td>

                    <td className="py-3 px-3 text-center font-mono">
                      {inv.priceVariance === 0 && inv.quantityVariance === 0 ? (
                        <span className="text-emerald-700 text-[11px] font-bold">
                          0% Zero Variance
                        </span>
                      ) : (
                        <div className="text-[10px]">
                          {inv.priceVariance !== 0 && (
                            <span className="text-rose-600 font-bold block">
                              Price: {formatCurrency(inv.priceVariance)}
                            </span>
                          )}
                          {inv.quantityVariance !== 0 && (
                            <span className="text-amber-600 font-bold block">
                              Qty: +{inv.quantityVariance}
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    <td className="py-2 px-3 text-center">
                        <ProcurementStatusBadge status={inv.matchStatus} />
                      </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setPrintableBill(inv);
                          }}
                          className="p-1.5 rounded bg-white hover:bg-zinc-100 text-[#71717A] hover:text-[#18181B] border border-[#D4D4D8] transition"
                          title="Print Formal Bill / Voucher Preview"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveInvoice(inv);
                          }}
                          className="p-1.5 rounded bg-zinc-100 hover:bg-zinc-200 text-[#71717A] hover:text-[#18181B] transition"
                          title="Inspect 3-Way Match"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {(inv.matchStatus === "matched" ||
                          inv.matchStatus === "discrepancy") && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleApproveInvoice(inv.id);
                            }}
                            disabled={isSubmitting}
                            className="text-[10px] bg-[#0D7A5F] hover:bg-[#0B6851] text-white font-bold px-2 py-1 rounded shadow-2xs transition"
                          >
                            Approve for AP
                          </button>
                        )}

                        {inv.matchStatus === "approved_for_payment" &&
                          onNavigateToPayment && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onNavigateToPayment(inv);
                              }}
                              className="text-[10px] bg-blue-600 hover:bg-blue-700 text-white font-bold px-2 py-1 rounded shadow-2xs transition flex items-center gap-1"
                            >
                              <CreditCard className="w-3 h-3" /> Pay Bill
                            </button>
                          )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Enter Supplier Invoice Modal */}
      <SideDrawer
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title={
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-[#0D7A5F]" />
            <span className="font-bold text-[#18181B] text-sm">
              Enter Supplier Invoice & Run 3-Way Match
            </span>
          </div>
        }
        subtitle="Critical Financial Control: Compares PO Rate vs GRN Physical Count vs Billed Amount"
        width="max-w-3xl"
        footer={
          <div className="flex items-center justify-between w-full">
            <div className="text-xs">
              <span className="text-[#71717A]">Gross Payable: </span>
              <span className="font-bold font-mono text-emerald-700 text-sm">
                {formatCurrency(calculatedSubtotal + (Number(taxAmount) || 0))}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 rounded-lg border border-[#D4D4D8] text-xs text-[#71717A] hover:bg-zinc-100 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="create-invoice-form"
                disabled={isSubmitting || billedItems.length === 0}
                className="px-5 py-2 rounded-lg bg-[#0D7A5F] hover:bg-[#0B6851] text-xs font-bold text-white shadow-2xs transition disabled:opacity-50"
              >
                {isSubmitting ? "Running 3-Way Match..." : "Verify & Save Invoice"}
              </button>
            </div>
          </div>
        }
      >
        <form id="create-invoice-form" onSubmit={handleCreateInvoice} className="space-y-4 pb-8 text-[#18181B]">
          
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
                  {formError}
                </div>
              )}

              {/* Linking PO */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-[#71717A] mb-1">
                    Select Originating Purchase Order *
                  </label>
                  <SearchableSelect
                    required
                    value={selectedPoId}
                    onChange={(val) => handlePoSelect(val)}
                    options={pos
                      .filter((p) => p.status !== "draft")
                      .map((p) => ({
                        value: p.id,
                        label: `${p.poNumber} — ${p.supplierName}`,
                        subLabel: `${p.items?.length || 0} items · Val: ${formatCurrency(p.totalAmount)}`,
                      }))}
                    placeholder="-- Choose PO --"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-[#71717A] mb-1">
                    Vendor&apos;s Billed Invoice Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    className="w-full bg-white border border-[#D4D4D8] rounded-lg px-3 py-1.5 text-xs text-[#18181B] font-mono focus:ring-1 focus:ring-[#0D7A5F] outline-none"
                    placeholder="e.g. INV-PK-89102"
                  />
                </div>
              </div>

              {/* Multi-GRN Selection Section */}
              {selectedPoId && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-mono text-[#3F3F46] uppercase tracking-wider font-bold">
                      Link Goods Receipt Notes (GRNs) to this Bill
                    </label>
                    <span className="text-[10px] text-purple-700 font-mono font-bold">
                      {selectedGrnIds.length} of {grns.filter((g) => g.poId === selectedPoId).length} GRN(s) Selected
                    </span>
                  </div>

                  {grns.filter((g) => g.poId === selectedPoId).length === 0 ? (
                    <div className="text-xs text-amber-700 italic">
                      No GRNs recorded yet for this PO. Goods must be physically received before 3-way matching.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {grns
                        .filter((g) => g.poId === selectedPoId)
                        .map((g) => {
                          const isChecked = selectedGrnIds.includes(g.id);
                          return (
                            <div
                              key={g.id}
                              onClick={() => toggleGrnSelection(g.id)}
                              className={cn(
                                "p-2.5 rounded-lg border text-xs cursor-pointer transition flex items-center justify-between",
                                isChecked
                                  ? "bg-white border-[#0D7A5F] shadow-xs"
                                  : "bg-white border-[#E4E4E7] text-[#71717A] opacity-70"
                              )}
                            >
                              <div className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => {}}
                                  className="rounded text-[#0D7A5F]"
                                />
                                <div>
                                  <span className="font-mono font-bold text-[#18181B] block">
                                    {g.grnNumber}
                                  </span>
                                  <span className="text-[10px] text-[#71717A]">
                                    {g.items?.length || 0} item(s) • {new Date(g.receivedDate || g.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                              <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                {g.qualityStatus || "Accepted"}
                              </span>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>
              )}

              {/* Dates & Tax */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-[#71717A] mb-1">
                    Supplier Invoice Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full bg-white border border-[#D4D4D8] rounded-lg px-3 py-1.5 text-xs text-[#18181B] focus:ring-1 focus:ring-[#0D7A5F] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-[#71717A] mb-1">
                    Payment Due Date
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-white border border-[#D4D4D8] rounded-lg px-3 py-1.5 text-xs text-[#18181B] focus:ring-1 focus:ring-[#0D7A5F] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-[#71717A] mb-1">
                    Sales Tax / GST Amount (PKR)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={taxAmount}
                    onChange={(e) => setTaxAmount(e.target.value)}
                    className="w-full bg-white border border-[#D4D4D8] rounded-lg px-3 py-1.5 text-xs text-[#18181B] font-mono focus:ring-1 focus:ring-[#0D7A5F] outline-none"
                    placeholder="0"
                  />
                </div>
              </div>

              {/* 3-WAY COMPARISON LINE ITEMS */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-[#18181B] block">
                  3-Way Match Audit Matrix ({billedItems.length} items)
                </span>

                {billedItems.length === 0 ? (
                  <div className="p-4 bg-[#F8FAFC] border border-[#EDEDED] rounded-xl text-center text-[#71717A] text-xs">
                    Please select a Purchase Order above to load PO agreed rates and GRN accepted physical counts.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {billedItems.map((it, idx) => {
                      const qtyDiff = it.billedQuantity - it.grnQuantity;
                      const priceDiff = it.billedUnitPrice - it.poUnitPrice;
                      const hasItemDiscrepancy = qtyDiff > 0.001 || priceDiff > 0.01;

                      return (
                        <div
                          key={idx}
                          className={cn(
                            "p-3 rounded-xl border text-xs space-y-2",
                            hasItemDiscrepancy
                              ? "bg-rose-50/50 border-rose-200"
                              : "bg-[#F8FAFC] border-[#EDEDED]"
                          )}
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-[#18181B]">{it.description}</span>
                            {hasItemDiscrepancy ? (
                              <span className="text-[10px] text-rose-600 font-bold flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5" /> Discrepancy Detected
                              </span>
                            ) : (
                              <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" /> Matched
                              </span>
                            )}
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                            {/* 1. PO Baseline */}
                            <div className="p-2 bg-white border border-[#EDEDED] rounded-lg">
                              <span className="block text-[9px] font-mono text-[#71717A] mb-0.5">
                                [1] PO Agreed Unit Rate
                              </span>
                              <span className="font-mono font-bold text-[#18181B]">
                                {formatCurrency(it.poUnitPrice)}
                              </span>
                            </div>

                            {/* 2. GRN Baseline */}
                            <div className="p-2 bg-white border border-[#EDEDED] rounded-lg">
                              <span className="block text-[9px] font-mono text-[#71717A] mb-0.5">
                                [2] GRN Accepted Qty
                              </span>
                              <span className="font-mono font-bold text-[#18181B]">
                                {it.grnQuantity} units
                              </span>
                            </div>

                            {/* 3. Supplier Billed Qty */}
                            <div>
                              <label className="block text-[10px] font-mono text-[#71717A] mb-0.5">
                                [3] Billed Qty *
                              </label>
                              <input
                                type="number"
                                min="0"
                                step="any"
                                required
                                value={it.billedQuantity}
                                onChange={(e) =>
                                  handleItemChange(idx, "billedQuantity", Number(e.target.value))
                                }
                                className={cn(
                                  "w-full rounded px-2.5 py-1 text-xs font-mono font-bold outline-none border",
                                  qtyDiff > 0.001
                                    ? "bg-rose-50 border-rose-300 text-rose-700"
                                    : "bg-white border-[#D4D4D8] text-[#18181B]"
                                )}
                              />
                            </div>

                            {/* 4. Supplier Billed Unit Price */}
                            <div>
                              <label className="block text-[10px] font-mono text-[#71717A] mb-0.5">
                                [3] Billed Unit Rate (PKR) *
                              </label>
                              <input
                                type="number"
                                min="0"
                                step="any"
                                required
                                value={it.billedUnitPrice}
                                onChange={(e) =>
                                  handleItemChange(idx, "billedUnitPrice", Number(e.target.value))
                                }
                                className={cn(
                                  "w-full rounded px-2.5 py-1 text-xs font-mono font-bold outline-none border",
                                  priceDiff > 0.01
                                    ? "bg-rose-50 border-rose-300 text-rose-700"
                                    : "bg-white border-[#D4D4D8] text-[#18181B]"
                                )}
                              />
                            </div>
                          </div>

                          {/* Variance Note */}
                          {hasItemDiscrepancy && (
                            <div className="text-[10px] text-rose-600 font-mono flex gap-3 pt-1 border-t border-rose-200">
                              {qtyDiff > 0 && (
                                <span>Quantity Overbilled by +{qtyDiff} units!</span>
                              )}
                              {priceDiff > 0 && (
                                <span>Unit Rate Surcharged by +{formatCurrency(priceDiff)}!</span>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Total Summary */}
              <div className="p-3 bg-[#F8FAFC] border border-[#EDEDED] rounded-xl flex items-center justify-between text-xs">
                <span className="text-[#71717A] font-semibold">
                  Invoice Gross Total (Subtotal + Tax):
                </span>
                <span className="text-base font-extrabold font-mono text-emerald-700">
                  {formatCurrency(calculatedSubtotal + (Number(taxAmount) || 0))}
                </span>
              </div>

              
        </form>
      </SideDrawer>

      {/* Invoice detail SideDrawer */}
      <SideDrawer
        isOpen={Boolean(activeInvoice)}
        onClose={() => setActiveInvoice(null)}
        title={
          activeInvoice ? (
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#0D7A5F]" />
              <span className="font-bold text-sm text-[#18181B]">
                3-Way Match Audit • {activeInvoice.invoiceNumber}
              </span>
            </div>
          ) : (
            "Invoice Audit"
          )
        }
        subtitle={
          activeInvoice
            ? `Vendor: ${activeInvoice.vendor?.name || "Vendor"} • PO: ${activeInvoice.po?.poNumber || "Direct"}`
            : undefined
        }
        width="max-w-2xl"
        footer={
          activeInvoice ? (
            <div className="flex items-center justify-between w-full">
              <button
                type="button"
                onClick={() => setActiveInvoice(null)}
                className="px-3.5 py-1.5 rounded-lg border border-[#D4D4D8] text-xs text-[#71717A] hover:bg-zinc-100"
              >
                Close
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const inv = activeInvoice;
                    setActiveInvoice(null);
                    setPrintableBill(inv);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#D4D4D8] text-xs font-semibold text-[#18181B] hover:bg-zinc-100 transition"
                >
                  <Printer className="w-3.5 h-3.5" /> Print / PDF
                </button>
                {(activeInvoice.matchStatus === "matched" || activeInvoice.matchStatus === "discrepancy") && (
                  <button
                    type="button"
                    onClick={() => handleApproveInvoice(activeInvoice.id)}
                    disabled={isSubmitting || !canApproveInvoice}
                    title={!canApproveInvoice ? "Missing permission" : undefined}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-[#0D7A5F] hover:bg-[#0B6851] text-white font-bold text-xs rounded-lg shadow-2xs transition"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Approve for Payment
                  </button>
                )}
                {activeInvoice.matchStatus === "approved_for_payment" && onNavigateToPayment && (
                  <button
                    type="button"
                    onClick={() => {
                      onNavigateToPayment(activeInvoice);
                      setActiveInvoice(null);
                    }}
                    className="px-4 py-1.5 rounded-lg bg-[#0D7A5F] text-white text-xs font-bold"
                  >
                    Record payment
                  </button>
                )}
              </div>
            </div>
          ) : null
        }
      >
        {activeInvoice && (
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded-xl border border-[#EDEDED] bg-[#F8FAFC] space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-[#18181B]">3-way match status</span>
                <ProcurementStatusBadge status={activeInvoice.matchStatus || "pending_match"} />
              </div>
              <p className="text-[11px] text-[#71717A]">
                {matchStatusLabel(activeInvoice.matchStatus).hint}
              </p>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2 rounded-lg bg-white border border-[#EDEDED]">
                  <div className="text-[10px] text-[#71717A] uppercase font-mono">Price variance</div>
                  <div className="font-mono font-bold text-[#18181B]">
                    {formatCurrency(activeInvoice.priceVariance || 0)}
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-white border border-[#EDEDED]">
                  <div className="text-[10px] text-[#71717A] uppercase font-mono">Qty variance</div>
                  <div className="font-mono font-bold text-[#18181B]">
                    {activeInvoice.quantityVariance || 0}
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-1">
              <div className="text-[11px] font-mono text-[#71717A]">Links</div>
              <div className="text-[#18181B]">
                PO: <span className="font-mono font-semibold">{activeInvoice.po?.poNumber || activeInvoice.poId || "—"}</span>
              </div>
              <div className="text-[#18181B]">
                GRN: <span className="font-mono font-semibold">{activeInvoice.grn?.grnNumber || "—"}</span>
              </div>
              <div className="text-[#18181B]">
                Total: <span className="font-mono font-bold text-emerald-700">{formatCurrency(activeInvoice.totalAmount || 0)}</span>
              </div>
            </div>
            {(activeInvoice.items || []).length > 0 && (
              <div className="border border-[#EDEDED] rounded-xl overflow-hidden">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-[#F8FAFC] text-[#71717A] font-mono text-[10px] uppercase">
                    <tr>
                      <th className="py-2 px-2">Description</th>
                      <th className="py-2 px-2 text-right">Billed qty</th>
                      <th className="py-2 px-2 text-right">Price</th>
                      <th className="py-2 px-2 text-right">Var</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EDEDED]">
                    {activeInvoice.items.map((it: any) => (
                      <tr key={it.id}>
                        <td className="py-1.5 px-2">{it.description}</td>
                        <td className="py-1.5 px-2 text-right font-mono">{it.billedQuantity}</td>
                        <td className="py-1.5 px-2 text-right font-mono">{formatCurrency(it.billedUnitPrice)}</td>
                        <td className="py-1.5 px-2 text-right font-mono">{formatCurrency(it.variance || 0)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {activeInvoice.matchNotes && (
              <p className="text-[11px] text-[#71717A] italic">Notes: {activeInvoice.matchNotes}</p>
            )}
          </div>
        )}
      </SideDrawer>

      {/* FORMAL PRINTABLE VENDOR BILL & 3-WAY MATCH VOUCHER DRAWER */}
      <SideDrawer
        isOpen={!!printableBill}
        onClose={() => setPrintableBill(null)}
        title={
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-[#0D7A5F]" />
            <span className="font-bold text-[#18181B] text-sm">
              Vendor Bill & Disbursement Voucher • {printableBill?.invoiceNumber}
            </span>
          </div>
        }
        subtitle="Official accounts payable 3-way match & tax audit endorsement"
        width="max-w-4xl"
        footer={
          <div className="flex items-center justify-between w-full">
            <button
              type="button"
              onClick={() => setPrintableBill(null)}
              className="px-4 py-2 border border-[#D4D4D8] rounded-lg text-xs text-[#71717A] hover:bg-[#F4F4F5]"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => printDocument("#printable-vendor-bill", `Vendor_Bill_${printableBill?.invoiceNumber}`)}
              className="inline-flex items-center gap-1.5 bg-[#0D7A5F] hover:bg-[#0B6851] text-white px-4 py-2 rounded-lg text-xs font-bold shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </button>
          </div>
        }
      >
        {printableBill && (
          <VendorBillDocument
            invoice={printableBill}
            onClose={() => setPrintableBill(null)}
          />
        )}
      </SideDrawer>
    </div>
  );
}
